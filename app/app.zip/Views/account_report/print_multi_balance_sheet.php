<title><?php echo $_SESSION['site_title']; ?></title>
<style>
table { border-collapse:collapse; font-size:11px; }
.inner_table tr:nth-child(even) { background:#F3F3F3; }
.inner_table tr:last-child { background:#e2dfdf; }
.table tr th, .table tr td { text-align:center; }
table td { padding:5px; line-height:1.5em; }
h2 { font-size: 20px; }
</style>
<tr><td colspan="2">
    <table style="width:100%">
    <tr><td width="15%" align="left"><img src="<?php echo base_url(); ?>/uploads/main/<?php echo $_SESSION['logo_img']; ?>" style="max-height: 80px;" align="left"></td>
    <td width="85%" align="center"><h2 style="text-align:center;margin-bottom: 0;"><?php echo $_SESSION['site_title']; ?></h2>
    <p style="text-align:center; font-size:16px; margin:5px 0px;"><?php echo $_SESSION['address1']; ?>, <?php echo $_SESSION['address2']; ?>,
	<?php echo $_SESSION['city']; ?> - <?php echo $_SESSION['postcode']; ?><br>
    Tel : <?php echo $_SESSION['telephone']; ?></p></td></tr>
    </table>
</td></tr>
<tr><td colspan="2"><hr></td></tr>
<tr><td colspan="2"><h2 style="text-align:center;">Balance Sheet</h2></td></tr>
<tr><td colspan="2">
	<table style="width:100%;" border="1">
    <thead><tr>
    <th>Account Name</th>
    <th>Bala Thandayuthapani</th>
    <th>Ganesha</th>
    <th>Ayyappa</th>
    <th>Naganathar</th>
    <th>T5Mariamman</th>
    <th>Maha Mariamman</th>
    <th>Kunj Bihari</th>
    <th>Ramar</th>
    <th>Vinayagar</th>
    <th>Thropathi Amman</th>
    <th>Sakthi Vinayagar</th>
    <th>Kaliamman</th>
    <th>Veerakaliyamman</th>
    </tr></thead>
    <tbody>
    		<tr style="color: black;">
					<td><b>ASSETS</b></td>
					<td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
					</tr>    		
                    <tr style="color: black;">
                    <td><span style="margin-left: 2%;color: black;">Current Assets</span></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 4%;">Cash-in-Hand</span></td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    <td style="text-align: right;">21,870.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">Cash Ledger</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">PETTY CASH</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">CASH DRAWER</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 4%;">Deposits</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 4%;">Loans and Advances</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 4%;">Bank Accounts</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">CIMB Bank</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 4%;">Stock-In-Hand</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 4%;">Sundry Debtors</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 4%;">Fixed Deposits</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 4%;">Burial Ground (Ayyappa Swamy)</span></td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    <td style="text-align: right;">-2,364.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">Overtime Fee</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">சவக்கூட தொகை/Parlour Fee</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">குளிர்சாதனப்பெட்டி/Refridgeration Fee</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">தகனம்/Cremation/Burial Fee</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 4%;">Burial Ground (Naganathar)</span></td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    <td style="text-align: right;">-2,585.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">Overtime Fee</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">சவக்கூட தொகை/Parlour Fee</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">குளிர்சாதனப்பெட்டி/Refridgeration Fee</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 6%;">தகனம்/Cremation/Burial Fee</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 2%;color: black;">FIXED ASSETS</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 2%;color: black;">Misc. Expenses</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 2%;color: black;">Investments</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		<tr style="color: black;">
                    <td><span style="margin-left: 2%;color: black;">Long Term Current Assets</span></td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    <td style="text-align: right;">0.00</td>
                    </tr>    		</tbody><tfoot><tr style="color: black;">
                    <td><b>Total Assets</b></td>
                    <td style="text-align: right;"><b>16,921.00</b></td>
                    </tr></tfoot></table>
</td></tr>
</table>
<script>
var css = '@page { size: landscape; }',
    head = document.head || document.getElementsByTagName('head')[0],
    style = document.createElement('style');

style.type = 'text/css';
style.media = 'print';

if (style.styleSheet){
  style.styleSheet.cssText = css;
} else {
  style.appendChild(document.createTextNode(css));
}

head.appendChild(style);

window.print();
</script>