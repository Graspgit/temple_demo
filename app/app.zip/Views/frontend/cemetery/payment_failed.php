<body style="background:linear-gradient(179deg, rgb(212 170 0) 0%, rgb(197 191 16) 35%, rgb(252 245 6) 100%);text-align:center;height:50vh;">
    <img src="https://rajamariamman.grasp.com.my/uploads/main/1687090400_514735_logo.jpg" style="width:80px; margin:20px auto 5px;">
    <h1 style="margin:10px;">RAJAMARIAMMAN TEMPLE</h1>
    
    <div style="padding:20px; margin:12vh auto;">
        <h1 style="text-align:center; font-size:112px; color:red; margin:15px;">&#10006;</h1>
        <h2 style="text-align:center;">Your Payment Failed. </h2>
    </div>
</body>